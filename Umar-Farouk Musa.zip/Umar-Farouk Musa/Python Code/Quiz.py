import time
chat_log = []
#This is used to print character by character
def draw_text(text, font_size=36):
    for char in text:
        print(char, end="", flush = True)
        time.sleep(0.01)

#It also does the same as above
def draw_chat():
    for line in chat_log[-6:]:
        draw_text(line)

#It adds text to the list to be printed
def kill(text):
    chat_log.append(text)

#This checks the answers for the football quiz
def check_foot():
    #This initializes the score variable
    score = 0
    int(score)
#This handles the answers for the football quiz
    if q1input == "a":
        score = score + 1
    else:
        print("The correct answer to Question 1 is a: Sporting Lisbon")
    if q2input == "b":
        score = score + 1
    else:
        print("The correct answer to Question 2 is b: 450")
    if q3input == "c":
        score = score + 1
    else:
        print("The correct answer to Question 3 is c: Luis Figo")
    if q4input == "a":
        score = score + 1
    else:
        print("The correct answer to Question 4 is a: Zico")
    if q5input == "c":
        score = score + 1
    else:
        print("The correct answer to Question 5 is c: 11")
    if q6input == "a":
        score = score + 1
    else:
        print("The correct answer to Question 6 is a: Gareth Barry")
    if q7input == "b":
        score = score + 1
    else:
        print("The correct answer to Question 7 is b: Frank Lampard")
    if q8input == "a":
        score = score + 1
    else:
        print("The correct answer to Question 8 is a: 23")
    if q9input == "c":
        score = score + 1
    else:
        print("The correct answer to Question 9 is c: Teddy Sherringham")
    if q10input == "a":
        score = score + 1
    else:
        print("The correct answer to Question 10 is a: Ronaldo")
    print("You scored", score)

#This checks the answer for the coding quiz
def code_check():
    if c1input == "b":
        score = score +1
    else:
        print("The correct answer to Question 1 is b: Begginer All Purpose Symbolic Instruction Code")
        print("Your answer was", c1input)
    if c2input == "a":
        score = score +1   
    else:
        print("The correct answer to Question 2 is a: Using the def function")
        print("Your answer was", c2input)
    if c3input == "b":
        score = score +1
    else:
        print("The correct answer to Question 3 is b: (Isia, Grawinmpa)")
        print("Your answer was", c3input)
    if c4input == "c":
        score = score +1
    else:
        print("The correct answer to Question 4 is a: Passes the information to a file")
        print("Your answer was", c4input)
    if c5input == "a":
        score = score +1
    else:
        print("The correct answer to Question 5 is a: Using the mkdir function")
        print("Your answer was", c5input)
    print("You scored", score)

#This handles the answers for the Technology quiz
def tech_check():    
    score = 0
    int(score)
    if q1input == "a":
        score = score +1
    else:
        print("The correct answer to Question 1 is a: 11")
    if q2input == "b":
        score = score +1
    else:
        print("The correct answer to Question 2 is a: Sergey Brin and Larry Page")
    if q3input == "c":
        score = score +1
    else:
        print("The correct answer to Question 3 is c: Ctrl X")
    if q4input == "a":
        score = score +1
    else:
        print("The correct answer to Question 4 is a: Interface")
    if q5input == "a":
        score = score +1
    else:
        print("The correct answer to Question 5 is a:", 1024** 4)
    print("You scored", score)

#This prints the main part of the Quiz
kill("Welcome to the Quiz\n")
kill("Input Football for a football based quiz\nInput Technology for a technology based quiz\nInput Coding for a programming quiz\n")
draw_chat()
chat_log = []
quizchoice = str(input("What is your preferred topic of choice: "))
if quizchoice == "Football" or "football":
    kill("Welcome to the football quiz\n")
    kill("There are 10 multiple-choice questions with 6 minutes\n")
#These are the questions for the football quiz
    draw_chat()
    chat_log = []
    print(" Input a for option a\n Input b for option b\n Input c for option c\n Input skip to skip the question")
    print("Question 1")
    print("What was Ronaldo's first club\na. Sporting Lisbon\nb. Manchester United\nc. Al Nassr")
    q1input = input("What is your answer: ")
    print("Question 2")
    print("How many goals did Ronaldo score for Real Madrid\na. 467\n b. 450\nc. 488")
    q2input = input("What is your answer: ")
    print("Question 3")
    print("Which of the following players did not play for Barcelona, Real Madrid and Inter Milan\na. Ronaldo Nazario\nb. Samuel Eto'o\nc. Luis Figo")
    q3input = input("What is your answer: ")
    print("Question 4")
    print("Who has scored the most freekicks in history\na. Zico\nb. Ronaldinho\nc. Lionel Messi")
    q4input = input("What is your answer: ")
    print("Question 5")
    print("Jamie Vardy scored in how many consecutive matches in the 2015/16 season?\na. 10\nb. 12\nc. 11")
    q5input = input("What is your answer: ")
    print("Question  6")
    print("Who is the player with the most Premier League appearances in history\na. Gareth Barry\nb. Alan Shearer\nc. Harry Winks")
    q6input = input("What is your answer: ")
    print("Question 7")
    print("Who is Chelsea's all time top scorer\na. Didier Drogba\nb. Frank Lampard\nc. Michael Owen")
    q7input = input("What is your answer: ")
    print("Question 8")
    print("What number did David Becckham wear for Real Madrid?\na. 23\nb. 7\nc. 10")
    q8input = input("What is your answer: ")
    print("Question 9")
    print("Which of the folowing players has not won a Balon D'Or?\na. Micheal Owen\nb. Zinedine Zidane\nc. Teddy Sherringham")
    q9input = input("What is your answer: ")
    print("Question 10")
    print("Who is the GOAT?\na.Ronaldo\nb.Messi\nc. None")
    q10input = input("What is your answer: ")
    chat_log = []
    check_foot()
    quizchoice = str(input("What is your preferred topic of choice: "))

#This is the technology part of the quiz
elif quizchoice == "Technology" or "technology":
    chat_log = []
    kill("Welcome to the Tecnology quiz\n")
    kill("There are 10 multiple-choice questions\n")
    print("Input a for option a\n Input b for option b\nInput c for option c\n")
    draw_chat()
    print("How many phones are in the Samsung Note Series\na. 11\nb.12\n21")
    t1input = input("What is your answer: ")
    print("Question 2")
    print("Which of the following two individuals created Google\na. Larry Page & Sergey Brin\nb. Bill Gates & Clinton Dempsey\nc. Harry Wilson & Jacobson Geoffrey")
    t2input = input("What is your answer: ")
    print("Question 3")
    print("What is the keyboard shortcut for cut and copy \na.Ctrl Z\nb. Ctrl T\nc. Ctrl X")
    t3input = input("What is your answer: ")
    print("Question 4")
    print("What is the I in API stand for \na. Interface \nb. Icon\nc. Index")
    t4input = input("What is your answer: ")
    print("Question 5")
    i = 4
    print("How many bytes are in a Terabyte \na. 1099511627776\nb. 658756498465\nc. 763589459872")
    t5input = input("What is your answer: ")
    tech_check()

#This is the coding part of the quiz
elif quizchoice == "Coding" or "coding":
    chat_log = []
    kill("Welcome to the Coding Quiz\n")
    kill("There are 5 multiple choice questions\n")
    kill("Input a for option a\n Input b for option b\nInput c for option c")
    draw_chat()
    print("Question 1")
    print("What does BASIC stand for \na. Basic All-Purpose Symbolic Index Command \nb. Beginner All-Purpose Symbolic Instruction Code \nc. Basic Alleviation Seminary Interface Code")
    c1input = input("What is your answer: ")
    print("Question 2")
    print("How do you define a function in Python \na. Using the def function\nb. Using the func-create command\nc. Using the def-function method")
    c2input = input("What is your answer: ")
    print("Question 3")
    print("Which of the following is a tuple \na.[ISIA, GWARINMPA] \nb.(Isia, Gwarinmpa) \nc. (tuple , list} ")
    c3input = input("What is your answer: ")
    print("Question 4")
    print("What does the <form action> tag do in HTML \na. Passes the information to a file\nb. Handles parsing errors\nc. Logging exception")
    c4input = input("What is your answer: ")
    print("Question 5")
    print("How do you make a folder from the command prompt \na. Using the mkdir function\nb. Using the newfolder method\nc. Using the createdir command")
    c5input = input("What is your answer: ")
    code_check()