while True:
    score = int(input("What is your score: "))
    if score > 90:
        print("You got an A1")
    elif score > 80 < 90:
        print("You got a B2")
    elif score > 75 < 80:
        print("You got a B3")
    elif score > 60 < 75:
        print("You got a C4")
    elif score > 55 < 60:
        print("You got a C5")
    elif score > 50 < 55:
        print("You got a P")
    elif score < 50:
        print("You are a failure F9")
