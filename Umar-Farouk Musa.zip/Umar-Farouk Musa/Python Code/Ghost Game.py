from random import randint
score = 0
print("Ghost Game")
print("There is a ghost behind one of the doors")
print("Choose one of the doors to continue (1,2 or 3)")
while True:
    doornum = randint(1,3)
    usinput = int(input("Which one do you choose: "))
    if usinput == doornum:
        print("There was a ghost \n You lost")
        print("You scored",score)
        score = 0
    elif usinput != "doornum":
        print("You can continue")
        score = score + 1
    elif usinput > 3:
        print("You are breaking the rules of the game and as a penalty you have lost all your points")
        score = 0