#By Umar-Farouk Musa
#Simple Calculator and age checker
from datetime import datetime
#Creating the calculator functions
def calculator():
    numa =  input("The first number: ")
    numb =  input("The second number: ")
    print("+ for addition")
    print("- for subtraction")
    print("* for multiplication")
    print("/ for division")
    oper = input("What is the operation to be performed: ")
    if oper == "+":
        print(numa, "+", numb ,"=" ,float(numa) + float(numb))
    elif oper == "-":
        print(numa ,"-" ,numb ,"=" ,float(numa) - float(numb))
    elif oper == "*":
        print(numa ,"*" ,numb, "=", float(numa) * float(numb))
    elif oper == "/":
        print(numa, "divided by", numb ,"=", float(numa) / float(numb))
#Creating the age checker functions
def checkage():
    print("To check your age input A")
    print("To check the year you were born input Y")
    aginput = input("What do you want to check: ")
    if aginput == "A":
        yeara = int(2025)
        yearb = int(input("Input your birth year: "))
        print("You are currently ",yeara - yearb,"years old")
    elif aginput == "Y":
        yeara = int(2025)
        yearb = int(input("Input your age: "))
        print("You are born in",yeara - yearb,)
        #simple login template in python
x = input("Input your name: ")
y = int(input("Input your age: "))
z = input("Input your password: ")
if len(z) < 5:
    print("Your password should be more than 5 letters")
else:
    print('Welcome',x)
a = input('Confirm your password: ')
if a == z:
    print('Succesful')
#To access the functions above
while True:
    print("What do you want to access\n Cal for Calculator\n Age for Age checker")
    userinput = str(input("Input your choice: "))
    if userinput == "Cal":
        calculator()
    elif userinput == "Age":
        checkage()